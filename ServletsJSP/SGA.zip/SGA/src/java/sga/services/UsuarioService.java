package sga.services;

import sga.eis.dto.Usuario;

/**
 *
 * @author Ubaldo
 */
public interface UsuarioService {

    public boolean usuarioExistente(Usuario usuario) ;
    
}
